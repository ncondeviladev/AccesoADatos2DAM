create function trg_valida_fecha_etapa_fn() returns trigger
    language plpgsql
as
$$
DECLARE
  f_ini DATE;
  f_fin DATE;
BEGIN
  SELECT fecha_inicio, fecha_fin INTO f_ini, f_fin
  FROM carreras WHERE id_carrera = NEW.id_carrera;
  IF f_ini IS NULL THEN
    RAISE EXCEPTION 'Carrera % no existe', NEW.id_carrera USING ERRCODE = '23503';
  END IF;
  IF NOT (NEW.fecha BETWEEN f_ini AND f_fin) THEN
    RAISE EXCEPTION 'Fecha de etapa % fuera del rango [% - %] para carrera %',
      NEW.fecha, f_ini, f_fin, NEW.id_carrera USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;

alter function trg_valida_fecha_etapa_fn() owner to "user";

